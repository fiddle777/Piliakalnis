package Core.Results;

public class ActionResult {
    public final String storyText;
    public ActionResult(String storyText) {
        this.storyText = storyText;
    }
}
